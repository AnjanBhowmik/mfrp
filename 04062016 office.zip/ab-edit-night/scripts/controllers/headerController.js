app.controller('headerController', function($scope,$location,$sessionStorage,loginService){
	
	$scope.userName = $sessionStorage.empName;
	$scope.userRole = $sessionStorage.empKey;

	// if(loginService.role=="HR-Staff"){
	// 	$scope.empListIf = true;
	// 	$scope.resourceListIf = false;
	// 	$scope.faqIf = true;

	// }

	//on logout session storage is getting cleared
	$scope.adminLogout = function(){

		$sessionStorage.$reset();
		$location.path('/login');
	};
	$scope.empList = function(event){
		console.log(event)
		var myEl = angular.element( document.querySelector( '#empList' ) );
myEl.addClass('active');
		$location.path('/employee_list');
	};
	$scope.empResource = function(){
		var myEl = angular.element( document.querySelector( '#roleId' ) );
myEl.addClass('active');

		$location.path('/resource_request');
	};
	$scope.empFaq = function(){
		var myEl = angular.element( document.querySelector( '#faqId' ) );
myEl.addClass('active');
		$location.path('/faq');
	};

});