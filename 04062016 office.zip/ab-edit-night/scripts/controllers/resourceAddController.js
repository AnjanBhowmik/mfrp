app.controller('resourceAddController', function($scope,$localStorage,$sessionStorage,randomString,resourceService){
	
	var empDataCopy={};
	resourceService.checkSession();

	var init=function(){
		$scope.empData = $localStorage.empDetails;
		if($scope.empData == null){
			$scope.empData = [];
		}
		$scope.employee={
				requestId:null,
				designation:null,
				experienceYears:null,
				number:null,
				skill:null,
				competency:null,
				position:null,
				location:null
		}
	};
		$scope.saveData = function(){
			var randomStr = randomString(5);
			$scope.employee.requestId=randomStr;

			$scope.empData.push($scope.employee);
			$localStorage.empDetails = angular.fromJson($scope.empData);
			console.log($scope.empData);

		};
	init();
});