app.factory('employeeService', function($http,$location, $q,$sessionStorage){
	var empSrv = {};//factory object
	empSrv.EmployeeData={};
	var dataStore=[];
	
	//checking session
	empSrv.checkSession = function(roleKey){
		//if(roleKey!=$sessionStorage.empKey)
		if($sessionStorage.empKey==null)
				$location.path('/login')
	}

	empSrv.getDatafromJSON = function(){
			
		var deferred = $q.defer();
		$http.get('json/empData.json').then(function(response){
			empSrv.EmployeeData = response.data;
			deferred.resolve(empSrv.EmployeeData);				
		},
		function (response) {
			deferred.reject(response);
		})

		return deferred.promise;
		 
	};
	
	
	


	return empSrv;//factory object returned
});