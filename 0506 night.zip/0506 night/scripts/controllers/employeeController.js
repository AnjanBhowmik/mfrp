app.controller('employeeController', function($scope,$localStorage,$sessionStorage,employeeService){
	
var empDataCopy={};
var mainIndex = -1;
//save and updates buttons to replace each other by ng-if

$scope.saveBtn=true;
$scope.updateBtn=false;


	var init=function(){

		$scope.employeeData = $localStorage.empStore;
		//console.log($scope.employeeData)
		if($scope.employeeData==null)
			$scope.employeeData=[];
		$scope.employee={
			
				employeeId:null,
				employeeName:null,
				title:null,
				position:null,
				competency:null,
				ContactNo:null,
				BloodGroup:null,
				Address:null,
				img:null
			
		}
	};
	
	//function for checkingsession
	employeeService.checkSession();

	//onloading the add/update user page data populates in table from JSON

	 // employeeService.getDatafromJSON().then(function(data){
	 // 	// empDataCopy.push($localStorage.empStore);
	 // 	// empDataCopy.push(data);
	 // 	//$localStorage.empStore = data;
	 // 	// console.log(data);
	 // 	// $scope.employeeData.push(data);
	 // 	// console.log($scope.employeeData)
	 // 	empDataCopy=data;
	 // 	console.log(empDataCopy)
	 // 	//init();
	 	
	 // });
	
	


	 //onclick of save button each data gets added to table from localStorage

	 $scope.addData =function(isValid){
	 	$scope.saveBtn=true;
		$scope.updateBtn=false;
		if(mainIndex!=-1){
			$localStorage.empStore.splice([mainIndex],1,$scope.employee)
		}
		else{
	 	$scope.employeeData.unshift($scope.employee);
	 	$localStorage.empStore = $scope.employeeData;
	 }
	 	
	 	init();
	 	$scope.empForm.$setUntouched();
	 };

	 //onclick of udit icon the fields get filled by particular employee details
	$scope.editData = function(index){
		mainIndex = index;
		console.log(mainIndex)
		//replace save button with update button
		$scope.saveBtn=false;
		$scope.updateBtn=true;
		//get the details of particular employee and display 
		$scope.employee = $localStorage.empStore[index]; 
		
		
		
	};

	// $scope.updateData = function(){
	// 	console.log(mainIndex)
	// 	console.log($scope.employee)
	// 	$localStorage.empStore.splice([mainIndex]-1,1);
	// 	$localStorage.empStore[mainIndex] = $scope.employee;
	// 	init();
	// };
	
	
init();
});