app.controller('resourceAddController', function($scope,$localStorage,$sessionStorage,randomString,employeeService){
	
	var empDataCopy={};
	employeeService.checkSession();
$scope.saveBtn=true;
$scope.updateBtn=false;
var mainIndex=-1;
	var init=function(){
		$scope.empData = $localStorage.empDetails;
		if($scope.empData == null){
			$scope.empData = [];
		}
		$scope.employee={
				requestId:null,
				designation:null,
				experienceYears:null,
				number:null,
				skill:null,
				competency:null,
				position:null,
				location:null
		}
	};
		$scope.addData = function(){
			$scope.saveBtn=true;
			$scope.updateBtn=false;
			
			// $scope.empData.push($scope.employee);
			// $localStorage.empDetails = angular.fromJson($scope.empData);
			// //$scope.reqForm.setPristine();
			// init();
			// $scope.reqForm.$setUntouched();

				//dfhkghejhgjejhgjehrg

			if(mainIndex!=-1){
			$localStorage.empDetails.splice([mainIndex],1,$scope.employee)
		}
			else{
				$scope.employee.requestId=randomString(6);
		 	$scope.empData.unshift($scope.employee);
		 	$localStorage.empDetails = $scope.empData;
	 }
	 	
		 	init();
		 	$scope.reqForm.$setUntouched();


		};//end of addData function

		//function to edit data

		$scope.editData = function(index){
			mainIndex = index;
		$scope.saveBtn=false;
		$scope.updateBtn=true;
		$scope.employee = $localStorage.empDetails[index];
		// $localStorage.empDetails[index] = $scope.employee[index];
		// console.log($localStorage.empDetails[index])
		// $localStorage.empDetails.splice([index],1)
	};

	$scope.accordion = function(event){
  			

		  angular.element('.collapse').on('shown.bs.collapse', function(){
		    angular.element(this).parent().find(".glyphicon-menu-down").removeClass(". glyphicon-menu-down").addClass("glyphicon-menu-up");
		  }).on('hidden.bs.collapse', function(){
		  angular.element(this).parent().find(".glyphicon-menu-up").removeClass("glyphicon-menu-up").addClass("glyphicon-menu-down");
		  });
       
  		}
	init();
});