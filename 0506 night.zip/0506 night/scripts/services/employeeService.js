app.factory('employeeService', function($http,$location, $q,$sessionStorage,$localStorage){
	var empSrv = {};//factory object
	var dataStore=[];
	
	//checking session
	empSrv.checkSession = function(){
		if($sessionStorage.empKey==null)
				$location.path('/login')
	}

	//empSrv.getDatafromJSON = function(){
		var init = function(){
			
		var deferred = $q.defer();
		$http.get('json/empData.json').then(function(response){
			empSrv.EmployeeData = response.data;
			deferred.resolve(response);	
			if($localStorage.empStore ==  null)
				$localStorage.empStore = response.data;
				else{
					angular.forEach($localStorage.empStore, function(val, key){
						dataStore.push($localStorage.empStore[key])
					})
					$localStorage.empStore = dataStore;
				}
				console.log(dataStore)		
		},
		function (response) {
			deferred.reject(response);
		})
		return deferred.promise;
		 
	};
	
init();

	return empSrv;//factory object returned
});