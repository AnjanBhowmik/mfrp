app.controller('employeeController', function($scope,$localStorage,$sessionStorage,employeeService){
	
var empDataCopy={};
//save and updates buttons to replace each other by ng-if
$scope.$parent.saveBtn=true;
$scope.$parent.updateBtn=false;

	var init=function(){
		$scope.employee={
		employeeId:null,
		employeeName:null,
		title:null,
		position:null,
		competency:null,
		ContactNo:null,
		BloodGroup:null,
		Address:null
		}
	};

	//onloading the add/update user page data populates in table from JSON
	 employeeService.getDatafromJSON().then(function(data){
	 	$localStorage.empStore = data;
	 	$scope.dataEmployeeController = $localStorage.empStore;
	 	empDataCopy=data;

	 });
	 //onclick of save button each data gets added to table from localStorage
	 $scope.addData =function(){
	 	empDataCopy.unshift(angular.fromJson($scope.employee));
	 	$localStorage.empStore = empDataCopy;
	 	$scope.dataEmployeeController = $localStorage.empStore;
	 	console.log(empDataCopy);
	 	console.log($scope.employee)
	 	init();

	 }
	 //onclick of udit icon the fields get filled by particular employee details
	$scope.editData = function(index){
		$scope.$parent.saveBtn=false;
		$scope.$parent.updateBtn=true;
		console.log(index);
		$scope.employee = $localStorage.empStore[index];
		$localStorage.empStore[index] = $scope.employee[index];
		$localStorage.empStore.splice([index],1)
	};
	
	
init();
});