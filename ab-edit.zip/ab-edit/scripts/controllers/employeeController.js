app.controller('employeeController', function($scope,$location,employeeService){
	

	var init = function(){
		employeeService.getDatafromJSON();

		$scope.employee={
		Id:null,
		Name:null,
		Title:null,
		Position:null,
		Competency:null,
		ContactNo:null,
		BloodGroup:null,
		Address:null
		}
		$scope.dataEmployeeController = employeeService.EmployeeData;
		console.log($scope.dataEmployeeController)
	};
	
	$scope.submitEmployeeForm = function(isValid){
		employeeService.getDatafromJSON();
		//$scope.dataEmployeeController = employeeService.EmployeeData;
	};
	
	$scope.addData = function(){

	}
init();
});