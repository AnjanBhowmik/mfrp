app.factory('employeeService', function($http,$location){
	var empSrv = {};
	empSrv.EmployeeData="";

	empSrv.getDatafromJSON = function(){
		$http.get('json/empData.json').then(function(response){
			empSrv.EmployeeData = response.data;
				console.log(empSrv.EmployeeData);	
		});
	};//end of getDatafromJSON()



	return empSrv;
});