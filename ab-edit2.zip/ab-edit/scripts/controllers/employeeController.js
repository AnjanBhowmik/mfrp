app.controller('employeeController', function($scope,$location,$http,employeeService){
	

	var init = function(){
		$scope.employee={
		Id:null,
		Name:null,
		Title:null,
		Position:null,
		Competency:null,
		ContactNo:null,
		BloodGroup:null,
		Address:null
		}
		
	};

	
	 employeeService.getDatafromJSON().then(function(data){
	 	$scope.dataEmployeeController = data;
	 	console.log($scope.dataEmployeeController);

	 });
	
	
	
	
init();
});