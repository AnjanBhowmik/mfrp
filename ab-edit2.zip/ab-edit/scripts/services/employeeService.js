app.factory('employeeService', function($http,$location, $q){
	var empSrv = {};
	empSrv.EmployeeData={};
	var dataStore=[];
	
	empSrv.getDatafromJSON = function(){

		 /*$http.get('json/empData.json').then(function(response){
			empSrv.EmployeeData = response.data;
			console.log(response.data);
						
				
		});*/

		var deferred = $q.defer();
		$http.get('json/empData.json').then(function(response){
			empSrv.EmployeeData = response.data;
			//console.log(response.data);
			deferred.resolve(empSrv.EmployeeData);				
		},
		function (response) {
			deferred.reject(response);
		})

		return deferred.promise;
		 
	};
	
	


	return empSrv;
});