app.factory('loginService',function($http,$location){
	var loginSrv={};
	loginSrv.JSONData="";//login details from JSON
	loginSrv.checkAllLoginDetails = function(userContent){
		
		//calling a function to get JSON data
		getDataFromJSON(userContent);
		
	};

	getDataFromJSON = function(userContent){
		$http.get('json/data.json').then(function(response){
			loginSrv.JSONData = response.data;
			//calling a function to match data entered by user
			matchUserNameNPassword(userContent);			
		});
	};//end of getDataFromJSON()

	matchUserNameNPassword = function(userContent){
		var nameMatch=passwordMatch=-1;
		var role="";
		angular.forEach(loginSrv.JSONData, function(value){
			if(value.name==userContent.loginName)
				nameMatch=0;
			if(value.password==userContent.password)
				passwordMatch=0;
			if(value.name == userContent.loginName && value.password == userContent.password)
				role=value.role;
		})//end of forEach loop
		if((nameMatch==-1 && passwordMatch==-1) || nameMatch==-1)
			alert("You are not Authorised");
		if(passwordMatch==-1 && nameMatch==0)
			alert("Wrong Password");
		if(role!=""){
			if(role=="HR-Manager")
				$location.path("/employee_list");
			if(role=="HR-Staff")
				$location.path("/resource_request");
			if(role=="Manager")
				$location.path("/");
		}
	};//end of matchUserNameNPassword()

	return loginSrv;
});