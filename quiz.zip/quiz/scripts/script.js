$( document ).ready(function() {
var data = null;
   $.ajax({
  dataType: "json",
  url: "json/questions.json",
  
  success: function(d){
  	data = d;
  	console.log(data)
  	addData(data)
  }
});//eof ajax call

   function addData(data){
   	var temp="";
   	// $.each(data,function(key,val){
   	// 	console.log(val.question)
   	// 	$('<li/>').attr({'id':key,'class':'questionsLi'}).append(val.question).appendTo('#list')

   	// 	$.each(data, function(key1,val1){
   	// 		$('<ul>').append('<li>').attr('class','optionsList').append("<input type='radio' id=key1+key>").val(val1.options[key]).appendTo(key)
   	// 	})				//id='myRadio"+i+"'
	
   	// })

   	var liQ = "";
   	$.each(data, function(key,val){
   		$('<li/>').attr({'id':key,'class':'questionsLi'}).append(val.question).appendTo('#list')
		console.log(val.options)
		addOptions(val.options);	

   	})//eof each loop
   }//eof addData()

   function addOptions(optionsData){
   	$.each(optionsData, function(key,val){
   		console.log(optionsData.val)
   		$('<p>').append("<input type='radio' id=key").val(optionsData[key]).append(optionsData[key]).appendTo('#kill')
   	})
   }
  
});//eof ready